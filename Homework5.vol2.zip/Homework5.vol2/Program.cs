﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Homework5.vol2
{
    static class Program
    {
        public static void SQLConnect()
        {
            string connectionString = "Integrated Security = True; Initial Catalog = MBBM_Test; Data Source = wsp6788d";
            SqlConnection connection = new SqlConnection(connectionString);
            var name = Console.ReadLine();
            connection.Open();
        }
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
