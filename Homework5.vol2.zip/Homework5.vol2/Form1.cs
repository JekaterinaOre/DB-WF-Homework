﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Homework5.vol2
{
    public partial class Form1 : Form
    {
        string connectionString = "Integrated Security = True; Initial Catalog = MBBM_Test; Data Source = wsp6788d";
        //int x = 0;
        public static void SQLConnect()
        {

        }
        public enum Gender
        {
            Male,
            Female,
            Unknown,
        }
        public Form1()
        {
            InitializeComponent();
            showdata();
            comboBox1.DataSource = Enum.GetValues(typeof(Gender));
            comboBox1.SelectedItem = Gender.Unknown;

        }
        private void AutoSizeGridColumn()
        {
            for (int i = 0; i < dataGridView1.Columns.Count; i++)
            {
                dataGridView1.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }
        }

        private void showAllbtn_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * from dbo.Persons", connection);
                DataTable dtbl = new DataTable();
                sqlDa.Fill(dtbl);
                dataGridView1.DataSource = dtbl;
                AutoSizeGridColumn();
            }

        }
        private void nameSearch_Click(object sender, EventArgs e)

        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * from dbo.Persons where Name = '" + searchName.Text + "'", connection);
                DataTable dtbl = new DataTable();
                sqlDa.Fill(dtbl);
                dataGridView1.DataSource = dtbl;
                searchName.Text = "";
            }
        }

        private void saveBtn_Click(object sender, EventArgs e)
        {
            string queryString = "Insert Into dbo.Persons Values ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + comboBox1.Text + "')";
            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand sqlCommand = new SqlCommand(queryString, connection))
            {
                sqlCommand.CommandType = CommandType.Text;
                connection.Open();
                DataTable dtbl = new DataTable();
                int i = sqlCommand.ExecuteNonQuery();
                MessageBox.Show("New entry created in the table!");
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                showdata();
            }
        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            var item = comboBox1.SelectedItem;
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            if (dataGridView1.Rows[i].Selected == true)
                {
                    int k = 0;
                    int.TryParse(dataGridView1.Rows[i].Cells[0].Value.ToString(), out k);
                    string queryString = "Update dbo.Persons set Name= '" + textBox1.Text + "' , Surname= '" + textBox2.Text + "' , Age= '" + textBox3.Text + "' , Gender= '" + comboBox1.Text + "'where PersonID = " + k;
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    using (SqlCommand sqlCommand = new SqlCommand(queryString, connection))
   
                    {
                        sqlCommand.CommandType = CommandType.Text;
                        connection.Open();
                        DataTable dtbl = new DataTable();
                        int b = sqlCommand.ExecuteNonQuery();
                        MessageBox.Show("Table updated!");
                        textBox1.Text = "";
                        textBox2.Text = "";
                        textBox3.Text = "";
                        showdata();
                    }
                }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells[1].Value.ToString();
                textBox2.Text = row.Cells[2].Value.ToString();
                textBox3.Text = row.Cells[3].Value.ToString();
                comboBox1.Text = row.Cells[4].Value.ToString();
            }
           
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                if (dataGridView1.Rows[i].Selected == true)
                {
                    int z = 0;
                    int.TryParse(dataGridView1.Rows[i].Cells[0].Value.ToString(), out z);
                    string queryString = "Delete from dbo.Persons where PersonID = " + z;
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    using (SqlCommand sqlCommand = new SqlCommand(queryString, connection))
                    {
                        sqlCommand.CommandType = CommandType.Text;
                        connection.Open();
                        DataTable dtbl = new DataTable();
                        int b = sqlCommand.ExecuteNonQuery();
                    }
                    MessageBox.Show("Entry deleted!");
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    showdata();
                }

            }
        }
        public void showdata()
          
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * from dbo.Persons", connection);
                DataTable dtbl = new DataTable();
                sqlDa.Fill(dtbl);
                dataGridView1.DataSource = dtbl;
                AutoSizeGridColumn();
            }
        }

    }
}

